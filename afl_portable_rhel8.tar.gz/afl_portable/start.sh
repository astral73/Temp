#!/bin/bash
echo "[*] AFL++ ortamı aktif."
export PATH=$(pwd):$PATH
bash
